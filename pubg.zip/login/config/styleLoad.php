<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- // The developer of this project is Saeed.
// Copying is possible with reference to the source.
// Ways of communication with Saeed :
// email: drsudosaeed@gmail.com
// telegram: @iioove
// instagram: sudosaeed -->