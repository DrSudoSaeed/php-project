<?php 
// The developer of this project is Saeed.
// Copying is possible with reference to the source.
// Ways of communication with Saeed :
// email: drsudosaeed@gmail.com
// telegram: @iioove
// instagram: sudosaeed
$keys_get = array_keys($_GET);
if(isset($keys_get[1])){
    header("Location: /pubg");
}

?>